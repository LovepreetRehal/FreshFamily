import 'package:active_ecommerce_flutter/my_theme.dart';
import 'package:flutter/material.dart';

class MyStyle{
  static final appBarStyle = TextStyle(fontSize: 16,fontWeight: FontWeight.bold,color: MyTheme.dark_font_grey);

}