class SocialConfig {
  var twitter_consumer_secret = "";
  var twitter_consumer_key = "";
}
