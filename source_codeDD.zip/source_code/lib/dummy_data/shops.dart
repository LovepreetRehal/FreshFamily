class Shop {
  String? id;
  String? image;
  String? name;

  Shop({this.id,this.image, this.name,});
}

final List<Shop> shopList = [
  Shop(id:"1",image: "dummy_assets/s1.jpg", name: "Baby and Mom"),
  Shop(id:"2",image: "dummy_assets/s2.jpg", name: "Clarks"),
  Shop(id:"3",image: "dummy_assets/s3.jpg", name: "Computer Seller",),
  Shop(id:"4",image: "dummy_assets/s4.jpg", name: "Dress House Private Limited"),
  Shop(id:"5",image: "dummy_assets/s5.jpg", name: "Maddison"),
  Shop(id:"6",image: "dummy_assets/s6.jpg", name: "New Balance"),
  Shop(id:"7",image: "dummy_assets/s7.jpg", name: "Tiffany and Co."),
  Shop(id:"8",image: "dummy_assets/s8.jpg", name: "UGG Australia"),
  Shop(id:"9",image: "dummy_assets/s9.jpg", name: "Vans \"of the wall\""),
  Shop(id:"10",image: "dummy_assets/s10.jpg", name: "Wear Dream Fashion"),
  Shop(id:"11",image: "dummy_assets/s11.jpg", name: "Zara"),
  Shop(id:"12",image: "dummy_assets/s12.jpg", name: "Zaris Fasion"),
];
