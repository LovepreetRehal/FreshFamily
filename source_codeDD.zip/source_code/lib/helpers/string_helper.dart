class StringHelper{

  bool? stringContains(string,part){
    return string.toLowerCase().contains(part.toLowerCase());
  }
}